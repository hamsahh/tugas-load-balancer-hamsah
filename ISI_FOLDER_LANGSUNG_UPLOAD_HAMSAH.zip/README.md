# Implementasi Load Balancing Menggunakan Docker dan Nginx

Project ini dibuat untuk tugas simulasi **load balancing** menggunakan **Docker**, **Docker Compose**, **Nginx**, dan **3 backend server Flask**. Sistem diuji menggunakan dua algoritma, yaitu **Round Robin** dan **Least Connection**.

## Identitas

Nama: **HAMSAH**

## Struktur Folder

```text
backend/
nginx/
scripts/
hasil-pengujian/
laporan/
README.md
docker-compose.yml
Laporan_Load_Balancer_HAMSAH.pdf
```

## Komponen Sistem

- **Backend**: aplikasi Flask sederhana yang memberikan response JSON.
- **Nginx**: digunakan sebagai load balancer.
- **Docker Compose**: digunakan untuk menjalankan semua container.
- **Round Robin**: membagi request secara bergiliran ke backend server.
- **Least Connection**: membagi request ke backend server yang memiliki koneksi paling sedikit.

## Alur Sistem

```text
Client/User
    |
    v
Nginx Load Balancer
    |
    |--- Backend-1
    |--- Backend-2
    |--- Backend-3
```

## Cara Menjalankan Project

Jalankan semua container:

```bash
docker compose up -d --build
```

Cek container:

```bash
docker compose ps
```

## Pengujian Round Robin

Round Robin berjalan pada port `8085`.

Buka browser:

```text
http://localhost:8085/
```

Atau jalankan script:

```bash
./scripts/test-roundrobin.sh
```

Untuk Windows:

```bat
scripts\test-roundrobin.bat
```

## Pengujian Least Connection

Least Connection berjalan pada port `8086`.

Buka browser:

```text
http://localhost:8086/
```

Atau jalankan script:

```bash
./scripts/test-leastconn.sh
```

Untuk Windows:

```bat
scripts\test-leastconn.bat
```

## Melihat Log Container

Log Round Robin:

```bash
docker logs roundrobin-lb
```

Log Least Connection:

```bash
docker logs leastconn-lb
```

## Menghentikan Container

```bash
docker compose down
```

## Kesimpulan

Simulasi ini menunjukkan bahwa load balancer dapat membagi request dari client ke beberapa backend server. Algoritma Round Robin membagi request secara bergiliran, sedangkan Least Connection memilih backend server dengan jumlah koneksi aktif paling sedikit.
