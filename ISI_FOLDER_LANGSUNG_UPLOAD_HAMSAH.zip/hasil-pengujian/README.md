# Hasil Pengujian

Folder ini digunakan untuk menyimpan screenshot hasil pengujian.

Screenshot yang disarankan:

1. Tampilan struktur folder GitHub.
2. Hasil `docker compose up -d --build`.
3. Hasil `docker compose ps`.
4. Hasil akses Round Robin di `http://localhost:8085/`.
5. Hasil akses Least Connection di `http://localhost:8086/`.
6. Log container Nginx Round Robin.
7. Log container Nginx Least Connection.
