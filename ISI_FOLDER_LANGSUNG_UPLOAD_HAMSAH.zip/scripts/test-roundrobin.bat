@echo off
echo === Pengujian Round Robin ===
for /L %%i in (1,1,12) do (
  echo Request ke-%%i
  curl http://localhost:8085/
  echo.
)
