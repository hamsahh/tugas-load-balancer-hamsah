#!/bin/bash

echo "=== Pengujian Least Connection ==="
for i in {1..12}
do
  echo "Request ke-$i"
  curl -s "http://localhost:8086/slow?delay=1" | python3 -m json.tool &
done
wait
echo "Selesai pengujian Least Connection"
