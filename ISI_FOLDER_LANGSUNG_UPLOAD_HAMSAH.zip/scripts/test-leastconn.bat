@echo off
echo === Pengujian Least Connection ===
for /L %%i in (1,1,12) do (
  echo Request ke-%%i
  start /B curl "http://localhost:8086/slow?delay=1"
)
echo Selesai menjalankan request Least Connection
