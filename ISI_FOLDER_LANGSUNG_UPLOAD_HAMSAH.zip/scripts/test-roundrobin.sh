#!/bin/bash

echo "=== Pengujian Round Robin ==="
for i in {1..12}
do
  echo "Request ke-$i"
  curl -s http://localhost:8085/ | python3 -m json.tool
  echo "--------------------------------"
done
